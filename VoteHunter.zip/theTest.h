#ifndef THETEST_H
#define THETEST_H
#include <iostream>

using namespace std;


//extern string qray[47];
class theTest
{
    public:
        theTest();
        virtual ~theTest();
        void questions(string qray[]);
        void results();
        void filler();
        void answerYes(int,int);
        void answerNo(int,int);
        void linkBuild();
        int nameray[5]{c,s,t,k,h};
        int c;
        int s;
        int t;
        int k;
        int h;
        int por;
        int sort1;
        int sort2;
        int sort3;
        int cj;
        int et;
        int ed;
        int fp;
        int gm;
        int sa;
        int hc;
        int im;
        int mj;
        int wa;
        int ra;
        int sc;


        string name1;
        string name2;
        string name3;
        string linkH;
        string linkS;
        string linkC;
        string linkK;
        string linkT;

        struct prez * prezray[4];


    protected:
    private:
};

struct prez{
        string fname;
        int points;
        prez * prev;

};
//prez * root;

#endif // THETEST_H
