#include <iostream>
#include <fstream>
#include <sstream>
#include "theTest.h"
#include <stdio.h>
#include <stdlib.h>

using namespace std;


string qray[49];
int ans;
int i;


theTest temp = theTest();

int main()
{

   // for(int x = 0; x<47; x++){
      //  cout<<qray[i]<<endl;
   // }


    while(true){

        cout<<"Vote Hunter       "<<endl;
        cout<<"---------         "<<endl;
        cout<<"1. Start the test "<<endl;
        cout<<"2. Quit           "<<endl;

        cin>>ans;


        if(ans==1){
            temp.filler();
            temp.results();
        }

        else if(ans==2){
            break;
        }

        else{
            cout<<"Please enter '1' or '2'"<<endl;
            cin.clear();
           // cin.ignore(std::numeric_limits<streamsize>::max(),'\n');
            cin.ignore(1000,'\n');
        }

    }

    return 0;
}
