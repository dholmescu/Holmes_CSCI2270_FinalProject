#include "theTest.h"
#include <iostream>
#include <fstream>
#include <sstream>

using namespace std;

theTest::theTest()
{
    //ctor


}

theTest::~theTest()
{
    //dtor
}

/*void theTest::questions(string qray[]){
    string pick;

    cout<<"Please answer each question as follows: 'Y' for Yes, 'N' for No, 'X' for I don't care"<<endl;

        int i;
    for(int x=0; x<48; x++){
        int i = x;
        cout<<qray[i]<<endl;
        cin>>pick;
        if(pick == "Y" or "y"){

        }
        else if(pick == "N" or "n"){

        }
        else if(pick == "X" or "x"){

        }
        else{
            cout<<"Please enter a valid choice: 'Y', 'N', 'X'"<<endl;
        }
    }


}*/

void theTest::results(){

if(h>=s){
	sort1 = h;
    name1 = "Clinton";

}
else{
	sort1 = s;
    name1 = "Sanders";
};

if(c>=k){
	sort2 = c;
	name2 = "Cruz";
}
else{
	sort2 = k;
	name2 = "Kasich";
};

if(sort1>=t){
	sort3=sort1;
	name3 = name1;
}
else{
	sort3=t;
	name3 = "Trump";
};
if(sort3>sort2){

	cout<<"The candidate that best aligns with your values is "<<name3<<" with "<<sort3<<" points"<<endl;
	cout<<"Your runner up is "<<name2<<" with "<<sort2<<" points"<<endl;
    if(name3 == "Trump"){
        cout<<"For more information on Donald Trump check out this link: https://www.donaldjtrump.com"<<endl;
    }
    else if(name3 == "Clinton"){
        cout<<"For more information on Hillary Clinton check out this link: https://www.hillaryclinton.com"<<endl;
    }
    else if(name3 == "Sanders"){
        cout<<"For more information on Bernie Sanders check out this link: https://berniesanders.com"<<endl;
    }

}
else{

	cout<<"The candidate that best aligns with your values is "<<name2<<" with "<<sort2<<" points"<<endl;
	cout<<"Your runner up is "<<name3<<" with "<<sort3<<" points"<<endl;
};





}
void theTest::linkBuild(){

    //root = new node(name3,sort3,NULL);
    //tempv = tempv->next;
//    prez * tempv = root;
  //  prez * runner = tempv -> prev;
//    string names[4] = {Cruz, Sanders, Clinton, Trump, Kasich};

    //prez * prezray[4];
    prezray[0] = ("Cruz", c , NULL);
    prezray[1] = ("Sanders", s , NULL);
    prezray[2] = ("Clinton", h , NULL);
    prezray[3] = ("Trump", t , NULL);
    prezray[4] = ("Kasich", k, NULL);

    if(h>=s){
        //sort1 = h;
       // name1 = "Clinton";

    }
    else{
        sort1 = s;
        name1 = "Sanders";
    };


/*    while(int i=0; i<5; i++){

      //  if(tempv == NULL){
            prez *tempv = new prez;
            tempv->fname = "Cruz"
            tempv->points = h;
            tempv->next =
        //}
        //else{
            if(h >= s){
                runner = new node(Sanders,s,NULL);
                tempv -> next = runner;
            }
            else{
                runner = new node(Sanders,s,NULL);
                runner -> next = tempv;
            }

        }
   // }*/

}
void theTest::filler(){
    string qray[49];
    int i = 0;
    string line;
    string ques;
    int counter = 0;
    string sel;


    ifstream infile;
    infile.open("polques.txt");

    if(infile.good()){
        cout<<"Please answer each question as follows: 'y' for Yes, 'n' for No, 'x' for I don't care"<<endl;


       // while(getline(infile,line)){
         //   stringstream ss(line);

        while(getline(infile,ques,'*') && (counter < 49)){
            qray[i] = ques;
            cout<<qray[i]<<endl;
            cin>>sel;
            if(sel != "x"){
                cout<<"Importace?(1-10)"<<endl;
                cin>>por;
            }
            else{

            };
            if(sel == "y" || sel == "yes" || sel == "Y" || sel == "Yes" || sel == "YES"){
                answerYes(i,por);

            }
            else if(sel == "n" || sel == "no" || sel == "N" || sel == "No" || sel == "NO"){
                answerNo(i,por);

            }
            else if(sel == "x" ||sel == "X" || sel == "i dont care" || sel == "I don't care" ){

            }
            else{
                cout<<"Please enter a valid choice: 'y', 'n', 'x'"<<endl;
            }
            i = (i+1);
            counter = counter + 1;

            }
       // }
    }
    else{
        cout<<"Bad File"<<endl;
    }


}

void theTest::answerYes(int i,int p){


    if(i==0){
        h=h+p;
        c=c+p;
        k=k+p;
        t=t+p;
        cj=cj+1;

    }
    else if(i==1){
        h=h+p;
        s=s+p;
        cj=cj+1;
    }
    else if(i==2){
        c=c+p;
        k=k+p;
        et=et+1;
    }
    else if(i==3){
        h=h+p;
        s=s+p;
        et=et+1;
    }
    else if(i==4){
        h=h+p;
        s=s+p;
        et=et+1;
    }
    else if(i==5){
        c=c+p;
        et=et+1;
    }
    else if(i==6){
        s=s+p;
        et=et+1;
    }
    else if(i==7){
        c=c+p;
        et=et+1;
    }

    else if(i==8){
        c=c+p;
        k=k+p;
        et=et+1;
    }
    else if(i==9){

    }
    else if(i==10){
        s=s+p;
        k=k+p;
    }
    else if(i==11){
        c=c+p;

    }
    else if(i==12){
        h=h+p;
        s=s+p;
    }
    else if(i==13){
        c=c+p;

    }
    else if(i==14){
        h=h+p;
        s=s+p;
    }
    else if(i==15){
        c=c+p;
        h=h+p;
        t=t+p;
    }
    else if(i==16){
        c=c+p;
    }
    else if(i==17){
        h=h+p;
        s=s+p;
    }
    else if(i==18){
        h=h+p;
        s=s+p;
    }
    else if(i==19){
        h=h+p;
        s=s+p;
    }
    else if(i==20){
        c=c+p;

    }
    else if(i==21){
        h=h+p;
        s=s+p;
    }
    else if(i==22){
        s=s+p;
    }
    else if(i==23){
        c=c+p;
    }
    else if(i==24){
        h=h+p;
        s=s+p;
    }
    else if(i==25){
        h=h+p;
        s=s+p;
    }
    else if(i==26){
        c=c+p;
        k=k+p;
    }
    else if(i==27){
        h=h+p;
        s=s+p;
    }
    else if(i==28){
        h=h+p;
        s=s+p;
    }
    else if(i==29){
        h=h+p;
        s=s+p;
    }
    else if(i==30){
        t=t+p;
    }
    else if(i==31){
        c=c+p;
        t=t+p;
    }
    else if(i==32){
        c=c+p;
        k=k+p;
        t=t+p;
    }
    else if(i==33){
        h=h+p;
        s=s+p;
        k=k+p;
    }
    else if(i==34){
        s=s+p;
    }
    else if(i==35){
        h=h+p;
        s=s+p;
    }
    else if(i==36){
        h=h+p;
        s=s+p;
        t=t+p;
    }
    else if(i==37){
        s=s+p;
    }
    else if(i==38){
        h=h+p;
        s=s+p;
        k=k+p;
    }
    else if(i==39){
        h=h+p;
        c=c+p;
        k=k+p;
        t=t+p;
    }
    else if(i==40){
        h=h+p;
        s=s+p;
    }
    else if(i==41){
        c=c+p;
        k=k+p;
    }
    else if(i==42){
        k=k+p;
        t=t+p;
    }
    else if(i==43){
        c=c+p;
        t=t+p;
    }
    else if(i==44){
        h=h+p;
        k=k+p;
    }
    else if(i==45){
        h=h+p;
        s=s+p;
        k=k+p;
        t=t+p;
    }
    else if(i==46){
        h=h+p;
        s=s+p;
    }
    else if(i==47){
        h=h+p;
        s=s+p;
    }
    else if(i==48){
        h=h+p;
        s=s+p;
    }
    else if(i==49){
        c=c+p;
        k=k+p;
        t=t+p;
    }



}

void theTest::answerNo(int i,int p){

    if(i==0){
        s = s+p;
    }

    else if(i==1){
        c=c+p;
        k=k+p;
        t=t+p;
    }
    else if(i==2){
        s= s+p;

    }
    else if(i==3){
        c=c+p;
        t=t+p;
    }
    else if(i==4){
        c=c+p;
        k=k+p;
    }
    else if(i==5){
        h=c+p;
        s=s+p;
        k=k+p;
    }
    else if(i==6){
        h=h+p;
    }
    else if(i==7){

    }
    else if(i==8){
        h=h+p;
        s=s+p;
    }
    else if(i==9){
        h=h+p;
        s=s+p;
        t=t+p;
    }
    else if(i==10){
        h=h+p;
        s=s+p;
    }
    else if(i==11){
        h=h+p;
        s=s+p;
        t=t+p;
    }
    else if(i==12){

    }
    else if(i==13){
        h=h+p;
        s=s+p;
    }
    else if(i==14){
        c=c+p;
    }
    else if(i==15){

    }
    else if(i==16){
        h=h+p;
        s=s+p;
        t=t+p;
    }
    else if(i==17){
        c=c+p;
        k=k+p;
        t=t+p;
    }
    else if(i==18){

    }
    else if(i==19){
        c=c+p;
    }
    else if(i==20){
        h=h+p;
        s=s+p;
        k=k+p;
    }
    else if(i==21){
        c=c+p;
        t=t+p;
    }
    else if(i==22){
        c=c+p;
        t=t+p;
    }
    else if(i==23){
        h=h+p;
        s=s+p;
        k=k+p;
        t=t+p;

    }
    else if(i==24){

        c=c+p;
    }
    else if(i==25){

        c=c+p;
        k=k+p;
        t=t+p;
    }
    else if(i==26){
        h=h+p;
        k=k+p;
    }

    else if(i==27){

    }
    else if(i==28){

        c=c+p;
        k=k+p;
        t=t+p;
    }
    else if(i==29){

    }
    else if(i==30){
        c=c+p;
        s=s+p;
    }
    else if(i==31){

    }
    else if(i==32){

        s=s+p;
    }
    else if(i==33){

      c=c+p;
      t=t+p;

    }
    else if(i==34){

        c=c+p;
    }
    else if(i==35){

        c=c+p;
        k=k+p;
        t=t+p;
    }
    else if(i==36){

    }
    else if(i==37){

        k=k+p;
    }
    else if(i==38){

    }
    else if(i==39){

        s=s+p;
    }
    else if(i==40){

        c=c+p;
        k=k+p;
        t=t+p;
    }
    else if(i==41){
        s=s+p;
        t=t+p;
    }
    else if(i==42){

        h=h+p;
        s=s+p;
    }
    else if(i==43){

        h=h+p;
        s=s+p;
    }
    else if(i==44){

        c=c+p;
    }
    else if(i==45){

        c=c+p;
    }
    else if(i==46){

        c=c+p;
    }
    else if(i==47){

        c=c+p;
        t=t+p;
    }
    else if(i==48){
        c=c+p;
        t=t+p;
    }
    else if(i==49){
        h=h+p;
        s=s+p;
    }

}
